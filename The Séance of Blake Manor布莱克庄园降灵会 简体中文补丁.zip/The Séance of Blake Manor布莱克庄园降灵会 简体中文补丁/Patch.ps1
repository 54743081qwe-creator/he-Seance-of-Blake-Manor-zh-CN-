﻿param(
 [ValidateSet('install','uninstall','check')][string]$Action='install',
 [ValidateSet('standard','manual')][string]$Mode='standard',
 [string]$GamePath='',
 [string]$SimHeiPath=(Join-Path $env:WINDIR 'Fonts\simhei.ttf'),
 [string]$UserDataPath=(Join-Path ([Environment]::GetFolderPath('UserProfile')) 'AppData\LocalLow\Spooky Doorway\The Seance of Blake Manor')
)
$ErrorActionPreference='Stop'
function Hash-File([string]$Path) { return [BlakePatchRuntime]::Hash([IO.File]::ReadAllBytes($Path)) }
function Check-Closed {
 if(Get-Process -Name 'The Seance of Blake Manor' -ErrorAction SilentlyContinue){throw '请先正常保存并退出游戏，再运行补丁。'}
}
function Safe-Child([string]$Root,[string]$Relative) {
 if([IO.Path]::IsPathRooted($Relative) -or $Relative -match '(^|[\\/])\.\.([\\/]|$)'){throw 'Invalid relative path'}
 $rootFull=[IO.Path]::GetFullPath($Root).TrimEnd('\')
 $target=[IO.Path]::GetFullPath((Join-Path $rootFull $Relative))
 if(-not $target.StartsWith($rootFull+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Path escaped target directory'}
 $part=$target
 while($part -and $part.Length -ge $rootFull.Length){
  if(Test-Path -LiteralPath $part){if((Get-Item -LiteralPath $part -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw ('不支持链接或重定向路径：'+$part)}}
  $part=[IO.Path]::GetDirectoryName($part)
 }
 return $target
}
function Write-State($value) { $json=$value | ConvertTo-Json -Depth 10;[IO.File]::WriteAllText($script:StatePath,$json,(New-Object Text.UTF8Encoding($false))) }
try {
 Check-Closed
 Add-Type -Path (Join-Path $PSScriptRoot 'PatchRuntime.cs')
 if(-not $GamePath){$GamePath=Read-Host '粘贴游戏安装目录（包含 The Seance of Blake Manor.exe 的文件夹）'}
 $GamePath=$GamePath.Trim().Trim('"');$GamePath=[IO.Path]::GetFullPath($GamePath)
 if(-not (Test-Path -LiteralPath (Safe-Child $GamePath 'The Seance of Blake Manor.exe'))){throw '未找到游戏 exe。请选择 Steam 的“浏览本地文件”打开的目录。'}
 $DataRoot=Safe-Child $GamePath 'The Seance of Blake Manor_Data'
 $BackupRoot=Safe-Child $GamePath '.blake-manor-zhcn-backup-1.0.0'
 $script:StatePath=Safe-Child $BackupRoot 'state.json'
 $manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
 if($manifest.format -ne 1 -or $manifest.version -ne '1.0.1'){throw '不支持的补丁清单。'}
 $allowed=@('resources.assets','level1','level121','Managed/SpookyDoorway.AdventureCreator.dll','Managed/SpookyDoorway.EldritchHouse.AC.dll','StreamingAssets/Localisations/Custom/fr/dialogueLocalisation.json','StreamingAssets/Localisations/Custom/fr/gameLocalisation.csv')
 if(@($manifest.files).Count -ne 7 -or @(Compare-Object ($allowed|Sort-Object) ($manifest.files.path|Sort-Object)).Count){throw '补丁文件清单不符合预期。'}
 $previous=$null;$previousText=$null
 if(Test-Path -LiteralPath $StatePath){
  $previousText=[IO.File]::ReadAllText($StatePath);$previous=$previousText|ConvertFrom-Json
  if($previous.version -notin @('1.0.0','1.0.1') -or $previous.gamePath -ne $GamePath -or $previous.phase -ne 'complete'){throw '发现未完成或不匹配的安装记录，请参照说明中的手动恢复步骤。'}
 }
 if($Action -eq 'uninstall' -and -not $previous){throw '没有本补丁的安装记录，不会改动游戏。'}
 $sources=@{};$current=@{}
 foreach($f in $manifest.files){
  $target=Safe-Child $DataRoot $f.path
  if(-not (Test-Path -LiteralPath $target)){throw ('缺少游戏文件：'+$f.path)}
  $current[$f.path]=[IO.File]::ReadAllBytes($target)
  $currentHash=[BlakePatchRuntime]::Hash($current[$f.path])
  if($previous){
   $entry=@($previous.files|Where-Object {$_.path -eq $f.path})
   if($entry.Count -ne 1 -or $entry[0].sha256 -ne $currentHash){throw ('游戏文件已被更新或其他补丁改动，已停止：'+$f.path)}
   $source=Safe-Child $BackupRoot ('original/'+$f.path)
  }else{$source=$target}
  if(-not (Test-Path -LiteralPath $source) -or (Hash-File $source) -ne $f.originalSha256){throw ('不支持的游戏版本或原件已被改动：'+$f.path+'。请先恢复原版文件。')}
  $sources[$f.path]=[IO.File]::ReadAllBytes($source)
 }
 $font=$null
 if($Action -ne 'uninstall'){
  if(-not (Test-Path -LiteralPath $SimHeiPath)){throw '未找到 Windows 黑体 simhei.ttf。本包不附带字体；请使用含该字体的 Windows，或通过 -SimHeiPath 指定你已有的合法字体文件。'}
  $font=[IO.File]::ReadAllBytes($SimHeiPath)
 }
 $jobs=@()
 foreach($f in $manifest.files){
  if($Action -eq 'uninstall'){$bytes=$sources[$f.path]}else{
   $variant=$f.variants.$Mode;$delta=Safe-Child $PSScriptRoot $variant.patch
   if((Hash-File $delta) -ne $variant.patchSha256){throw ('补丁数据损坏：'+$variant.patch)}
   $bytes=[BlakePatchRuntime]::Apply($delta,$sources[$f.path],[long]$variant.length)
   if([BlakePatchRuntime]::Hash($bytes) -ne $variant.sha256){throw ('重建校验失败：'+$f.path)}
   if($f.path -eq 'resources.assets'){
    $fc=$manifest.font
    $bytes=[BlakePatchRuntime]::AddLocalFont($bytes,$sources[$f.path],$font,$fc.object_entry,$fc.source_offset,$fc.source_size,$fc.data_offset)
   }
  }
  $jobs+=@{path=$f.path;target=(Safe-Child $DataRoot $f.path);data=$bytes;sha256=[BlakePatchRuntime]::Hash($bytes)}
 }
 # Only the language preference is edited. With no preferences file, the
 # patched native default initializer selects Chinese on first launch.
 $optionsPath=Safe-Child $UserDataPath 'SOBMOptions'
 $exists=Test-Path -LiteralPath $optionsPath
 $languageBefore=-1;$optionsBytes=$null
 if($exists){
  $optionsBytes=[IO.File]::ReadAllBytes($optionsPath)
  # The game legitimately stores cameraFOV and CameraFOV together. Windows
  # PowerShell ConvertFrom-Json treats these as duplicate keys; the framework
  # serializer keeps JSON property names case-sensitive without rewriting them.
  Add-Type -AssemblyName System.Web.Extensions
  $optionsParser=New-Object System.Web.Script.Serialization.JavaScriptSerializer
  $parsedOptions=$optionsParser.DeserializeObject([BlakePatchRuntime]::OptionsJson($optionsBytes))
  $languageBefore=[BlakePatchRuntime]::Language($optionsBytes)
  if($parsedOptions -isnot [System.Collections.IDictionary] -or -not $parsedOptions.ContainsKey('language') -or $parsedOptions['language'] -ne $languageBefore){throw '语言设置解析不一致，已停止。'}
 }
 $languageState=@{path=$optionsPath;originalValue=$languageBefore;existedBeforeInstall=[bool]$exists;active=($Action -ne 'uninstall')}
 if($previous -and $previous.mode -ne 'uninstalled' -and $previous.language){
  if($previous.language.path -ne $optionsPath){throw '语言备份属于另一用户配置目录，请在原用户下操作，或用 -UserDataPath 指定原目录。'}
  $languageState.originalValue=[int]$previous.language.originalValue
  $languageState.existedBeforeInstall=[bool]$previous.language.existedBeforeInstall
 }
 $desiredLanguage=1
 if($Action -eq 'uninstall'){$desiredLanguage=[int]$languageState.originalValue}
 # Respect a language explicitly selected by the player after installation.
 $editLanguage=$exists -and ($Action -ne 'uninstall' -or ($previous.language -and $languageBefore -eq 1))
 if($editLanguage -and $languageBefore -ne $desiredLanguage){
  $updatedOptions=[BlakePatchRuntime]::SetLanguage($optionsBytes,$desiredLanguage)
  $current['@language']=$optionsBytes
  $jobs+=@{path='@language';target=$optionsPath;data=$updatedOptions;sha256=[BlakePatchRuntime]::Hash($updatedOptions)}
 }
 if($Action -eq 'check'){Write-Host '检查通过：七个游戏文件可重建，中文默认设置可应用；游戏和个人设置均未修改。';exit 0}
 Check-Closed
 foreach($j in $jobs){if((Hash-File $j.target) -ne [BlakePatchRuntime]::Hash($current[$j.path])){throw '文件在准备期间发生变化，已停止。'}}
 if(-not $previous){
  foreach($f in $manifest.files){
   $backup=Safe-Child $BackupRoot ('original/'+$f.path)
   [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($backup))|Out-Null
   if(Test-Path -LiteralPath $backup){if((Hash-File $backup) -ne $f.originalSha256){throw '已有备份不匹配，不会覆盖。'}}else{[IO.File]::WriteAllBytes($backup,$sources[$f.path])}
   if((Hash-File $backup) -ne $f.originalSha256){throw '备份核验失败。'}
  }
 }
 $state=@{version='1.0.1';gamePath=$GamePath;phase='installing';mode=$Mode;language=$languageState;files=@($jobs|Where-Object {$_.path -ne '@language'}|ForEach-Object {@{path=$_.path;sha256=$_.sha256}});updated=(Get-Date).ToString('o')}
 Write-State $state
 $done=@()
 try {
  foreach($j in $jobs){
   Check-Closed
   if((Hash-File $j.target) -ne [BlakePatchRuntime]::Hash($current[$j.path])){throw ('文件在安装期间发生变化：'+$j.path)}
   [BlakePatchRuntime]::Replace($j.target,$j.data);$done+=$j
   if((Hash-File $j.target) -ne $j.sha256){throw ('写入后校验失败：'+$j.path)}
  }
  if($Action -eq 'uninstall'){$state.mode='uninstalled'}
  $state.phase='complete';Write-State $state
 }catch{
  $failure=$_
  foreach($j in @($done | Sort-Object path -Descending)){[BlakePatchRuntime]::Replace($j.target,$current[$j.path])}
  if($previousText){[IO.File]::WriteAllText($StatePath,$previousText,(New-Object Text.UTF8Encoding($false)))}else{
   $state.phase='complete';$state.mode='uninstalled';$state.language.active=$false;$state.files=@($manifest.files|ForEach-Object {@{path=$_.path;sha256=$_.originalSha256}});Write-State $state
  }
  throw $failure
 }
 if($Action -eq 'uninstall'){Write-Host '卸载完成，七个原始文件已恢复；语言偏好按记录处理，备份保留，存档未改动。'}else{
  Write-Host ('安装完成，模式：'+$Mode+'。直接启动游戏即可默认使用简体中文。')
  Write-Host '语言选择已处理；画质、音量、按键、存档和系统语言设置未改动。'
 }
 exit 0
}catch{Write-Host ('失败：'+$_.Exception.Message) -ForegroundColor Red;exit 1}
