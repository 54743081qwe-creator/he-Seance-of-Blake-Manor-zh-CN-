using System;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
public static class BlakePatchRuntime {
 static readonly UTF8Encoding StrictUtf8=new UTF8Encoding(false,true);
 static readonly Regex LanguagePattern=new Regex("\"language\"\\s*:\\s*(-?[0-9]+)");
 public static string OptionsJson(byte[] data) {
  if(data.Length<6||data[0]!=74||data[1]!=115||data[2]!=111||data[3]!=110)throw new InvalidDataException("Unsupported SOBMOptions header; no settings changed");
  return StrictUtf8.GetString(data,4,data.Length-4);
 }
 public static int Language(byte[] data) {
  var matches=LanguagePattern.Matches(OptionsJson(data));if(matches.Count!=1)throw new InvalidDataException("Expected exactly one language field");
  return int.Parse(matches[0].Groups[1].Value,System.Globalization.CultureInfo.InvariantCulture);
 }
 public static byte[] SetLanguage(byte[] data,int value) {
  string text=OptionsJson(data);Language(data);var match=LanguagePattern.Match(text).Groups[1];
  string changed=text.Substring(0,match.Index)+value.ToString(System.Globalization.CultureInfo.InvariantCulture)+text.Substring(match.Index+match.Length);
  var body=StrictUtf8.GetBytes(changed);var output=new byte[4+body.Length];Array.Copy(data,output,4);Array.Copy(body,0,output,4,body.Length);return output;
 }
 public static string Hash(byte[] b) { using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(b)).Replace("-","").ToLowerInvariant(); }
 public static byte[] Apply(string patch,byte[] original,long expectedLength) {
  if(expectedLength<0||expectedLength>536870912)throw new InvalidDataException("Invalid output length");
  using(var f=File.OpenRead(patch))using(var gz=new GZipStream(f,CompressionMode.Decompress))using(var r=new BinaryReader(gz))using(var output=new MemoryStream()) {
   if(r.ReadUInt32()!=0x31434D42||r.ReadInt64()!=expectedLength)throw new InvalidDataException("Invalid patch header");
   while(true){int op=r.ReadByte();if(op==255)break;
    if(op==0){long pos=r.ReadInt64();int n=r.ReadInt32();if(pos<0||n<0||pos>original.LongLength-n||output.Length>expectedLength-n)throw new InvalidDataException("Invalid copy range");output.Write(original,(int)pos,n);}
    else if(op==1){int n=r.ReadInt32();if(n<0||output.Length>expectedLength-n)throw new InvalidDataException("Invalid literal range");var bytes=r.ReadBytes(n);if(bytes.Length!=n)throw new EndOfStreamException();output.Write(bytes,0,n);}
    else throw new InvalidDataException("Invalid patch operation");
   }
   if(output.Length!=expectedLength||gz.ReadByte()!=-1)throw new InvalidDataException("Patch length mismatch");return output.ToArray();
  }
 }
 public static byte[] AddLocalFont(byte[] resource,byte[] original,byte[] font,int objectEntry,int sourceOffset,int sourceSize,int dataOffset) {
  if(font.Length<10000||font.Length>100000000||font[0]!=0||font[1]!=1||font[2]!=0||font[3]!=0)throw new InvalidDataException("A valid local SimHei TrueType font is required");
  const int fontOffset=2216,oldFontSize=350200;
  if(BitConverter.ToInt32(original,sourceOffset+2212)!=oldFontSize)throw new InvalidDataException("Original font layout mismatch");
  using(var ms=new MemoryStream())using(var w=new BinaryWriter(ms)) {
   w.Write(resource);while(ms.Length%16!=0)w.Write((byte)0);long start=ms.Position;
   w.Write(original,sourceOffset,2212);w.Write(font.Length);w.Write(font);while((ms.Position-start)%4!=0)w.Write((byte)0);
   w.Write(original,sourceOffset+fontOffset+oldFontSize,sourceSize-fontOffset-oldFontSize);long size=ms.Position-start;
   ms.Position=objectEntry+8;w.Write(start-dataOffset);w.Write((int)size);
   ms.Position=24;var len=BitConverter.GetBytes(ms.Length);Array.Reverse(len);w.Write(len);return ms.ToArray();
  }
 }
 public static void Replace(string path,byte[] data) {
  string temp=path+".blake-zhcn.tmp";
  if(File.Exists(temp))throw new IOException("Temporary file already exists: "+temp);
  try {using(var f=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)){f.Write(data,0,data.Length);f.Flush(true);}File.Replace(temp,path,null);}
  finally {if(File.Exists(temp))File.Delete(temp);}
 }
}
